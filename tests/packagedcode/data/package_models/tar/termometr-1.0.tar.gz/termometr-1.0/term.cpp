#include <cstdio>

int main () {

char s;
double t;
printf ("\n\n\Termometr\n\nby Artur Wrona");
printf ("\n\nTen program sluzy do przeliczania roznych skal temperatur \n\n\n");
printf ("Aby rozpoczac prace, wpisz litere odpowiadajaca skali:\nc - celsjusza\nf - fahrenheita\nk - kelvina\n\n\n\n");
printf ("Podaj skale c,f,k lub wcisnij q, by wyjsc: ");
scanf ("%c", &s);

	if (s == 'c')
		{
		printf ("Temperatura w skali Celsjusza: ");
		scanf ("%lf", &t);
		printf ("Temperatura w skali Fahrenheita: %lf \n", 1.8*t+32);
		printf ("Temperatura w skali Kelvina: %lf \n\n", t+273);
		}
	else
	if (s == 'f')
		{
		printf ("Temperatura w skali Fahrenheita: ");
		scanf ("%lf", &t);
		printf ("Temperatura w skali Celsjusza: %lf \n", t*5/9-32*5/9);
		printf ("Temperatura w skali Kelvina: %lf \n\n", (t*5)/9-(32*5)/9+273);
		}
	else
	if (s == 'k')
		{
		printf ("Temperatura w skali Kelvina: ");
		scanf ("%lf", &t);
		printf ("Temperatura w skali Fahrenheita: %lf \n", (t-273)*1.8+32);
		printf ("Temperatura w skali Celsjusza: %lf \n\n", t-273);
		}
	else
	if (s == 'q')
		{
		printf ("\n\nWidze, ze nie przypadl Ci do gustu moj programik\n\n");
		printf ("Dopiero zaczalem programowac, wiec nie spodziewaj sie po mnie jakis fajerwerkow\n");
		printf ("\n\nDo widzenia, kup se trabke do pierdzenia!!!\n\n");	
		}
	else

printf ("\n\nDo widzenia, kup se trabke do pierdzenia\n\nArtur Wrona"); 
return 0;
}
