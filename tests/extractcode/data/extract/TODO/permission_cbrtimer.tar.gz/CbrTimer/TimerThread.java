/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CbrTimer;

import java.util.Vector;
import java.util.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.Manager;
        
/**
 *
 * @author alessandro
 */
public class TimerThread extends Thread {
    
    private CbrTimer app;
    private int[] tempo;
    private boolean interrupted;
    public TimerThread(CbrTimer m) {
        app = m;
        tempo =convertTime(m.getTTIme().getString());
        this.interrupted=false;
        
    }
    private int[] convertTime(String time){
        int [] ret=new int[3];
        char[] car=time.toCharArray();
        if ((car[2]!=':')||(car[5]!=':')||time.length()!=8)
            throw new NumberFormatException();
        ret[0]=Integer.parseInt(new String(car,0,2));
        ret[1]=Integer.parseInt(new String(car,3,2));
        ret[2]=Integer.parseInt(new String(car,6,2));

        return ret;
    }
    private int toSecond(int[] time){
        return time[2]+time[1]*60+time[0]*3600;
    }
    private String timeToString(int time){
        int ore,minuti,secondi,tmp;
        String ret,ores,mins,secs;
        tmp=time;
        ore=tmp/3600;
        if (ore<=9)
            ores="0"+Integer.toString(ore);
        else
            ores=Integer.toString(ore);
        tmp=tmp%3600;
        minuti=tmp/60;
        if (minuti<=9)
            mins="0"+Integer.toString(minuti);
        else
            mins=Integer.toString(minuti);
        secondi=tmp%60;
        if (secondi<=9)
            secs="0"+Integer.toString(secondi);
        else
            secs=Integer.toString(secondi);
        ret=ores+":"+mins+":"+secs;
       return ret;
    }
    public void setInterrupt(boolean value){
        this.interrupted=value;
    }
    public void run() {
        
        int countdown=toSecond(tempo);
        app.getGauge().setMaxValue(countdown);
        while(!interrupted){
            try{
                app.getSElap().setText(timeToString(countdown));
                app.getGauge().setValue(countdown--);
                
                Thread.sleep(1000);
                if (countdown==0){
                    app.getGauge().setValue(0);
                    app.getSElap().setText(timeToString(countdown));
                    break;
                }
                    
            }catch(Exception e){
                e.printStackTrace();
                this.setInterrupt(true);
                this.interrupt();
            }
        }
        
        try{
            if (!interrupted){
                for (int i=0;i<10;i++){
                    Manager.playTone(100,100,100);
                    Thread.sleep(500);
                    
                }
                Manager.playTone(100,2000,100);
            }
        }catch(Exception e){
         e.printStackTrace();
         app.getFTimer().append("ERROR");
        }
        finally{
            this.interrupted=true;
            this.interrupt();
        }
        
    }
}
