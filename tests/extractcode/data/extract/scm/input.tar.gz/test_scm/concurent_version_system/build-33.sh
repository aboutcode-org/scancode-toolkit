#./build.sh minimal
#./build.sh expert-java
#open /build_331/distro-releases/EasyEclipse\ Expert\ Java\ 1.3.1.pkg/
#open /build_331/distro-releases/EasyEclipse\ Minimal\ 1.3.1.pkg/
./checks.sh -d expert-java
#./build.sh desktop-java
#open /build_331/distro-releases/EasyEclipse\ Desktop\ Java\ 1.3.1.pkg/
./checks.sh -d desktop-java # has error
./build-and-check-plugin.sh eclipse-jdt
./build-and-check-plugin.sh eclipse-tools
./build-and-check-plugin.sh eclipse-wtp-web
./build-and-check-plugin.sh eclipse-wtp-j2ee
./build-and-check-plugin.sh eclipse-cvs
./build-and-check-plugin.sh eclipse-sdk
./checks.sh eclipse-sdk minimal # has error
./build-and-check-plugin.sh eclipse-rcpdelta # check has errors
./build-and-check-plugin.sh tomcat-launcher
./checks.sh tomcat-launcher minimal
./build-and-check-plugin.sh anyedit
./build-and-check-plugin.sh eclipseutils
./build-and-check-plugin.sh cbg-editor
./build-and-check-plugin.sh springide # check has error
./build-and-check-plugin.sh eclipse-dtp
./build-and-check-plugin.sh jboss-hibernate-tools
./build-and-check-plugin.sh weblogic-eclipse
./build-and-check-plugin.sh amateraside
./build-and-check-plugin.sh jarlaunch

# new on 1/17/08
./build-and-check-plugin.sh subclipse
./build-and-check-plugin.sh fatjar
./build-and-check-plugin.sh jarplug # already in 1.3, do we need to re-release ?
./build-and-check-plugin.sh jarlaunch # upgraded version, no change
./build-and-check-plugin.sh quantum # builds, to check
./build-and-check-plugin.sh jboss-ide # builds, replaces jboss-ide-ejb3-aop (to verify, and to update the site)

# new for cplusplus
./build-and-check-plugin.sh eclox-doxygen
./build-and-check-plugin.sh eclipse-cdt

#new for mobile-java
./build-and-check-plugin.sh eclipseme

# forgotten !
./build-and-check-plugin.sh eclipse-examples


