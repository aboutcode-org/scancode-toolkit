./build.sh $1
./checks.sh $1 minimal
