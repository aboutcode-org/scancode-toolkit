#  Copyright (c) 2003-2008 by nexB, Inc. http://www.nexb.com/ - All rights reserved.
#  This software is licensed under the terms of the Open Software License version 2.1.
#  A copy of the license is available at http://opensource.org/licenses/osl-2.1.php
./anteclipse clean
chmod a+x build-all-distro.sh
chmod a+x build.sh
./build-all-distro.sh
./build.sh release