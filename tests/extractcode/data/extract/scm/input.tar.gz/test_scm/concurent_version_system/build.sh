#!/bin/sh

#  Copyright (c) 2003-2008 by nexB, Inc. http://www.nexb.com/ - All rights reserved.
#  This software is licensed under the terms of the Open Software License version 2.1.
#  A copy of the license is available at http://opensource.org/licenses/osl-2.1.php


# even better: put that in your shell first
#alias build=./build.sh

if [ $2 ]; then
  	BUILD_OPTS=" -Did=$1 -Dbuildtype=$2"
else
  	BUILD_OPTS=" -Did=$1"
fi

echo Running ./anteclipse -f build.xml build-one $BUILD_OPTS

OS=`uname`
if ./anteclipse -f build.xml build-one $BUILD_OPTS; then
  if [ $OS == 'Darwin' ]; then
    say $2 build of component $1 has completed successfully &
  fi
  exit 0
else
  if [ $OS == 'Darwin' ]; then
    say $2 build of component $1 has almost succeeded &
  fi
  exit -1
fi
