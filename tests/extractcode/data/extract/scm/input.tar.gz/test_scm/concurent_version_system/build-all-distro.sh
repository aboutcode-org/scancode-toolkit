#  Copyright (c) 2003-2008 by nexB, Inc. http://www.nexb.com/ - All rights reserved.
#  This software is licensed under the terms of the Open Software License version 2.1.
#  A copy of the license is available at http://opensource.org/licenses/osl-2.1.php

#
# IF you motify this list of distros, you must also modify:
# - build-all-distro.bat
# - repository/sets/release-distributions.xml
#
./build.sh expert-java
./build.sh desktop-java
./build.sh plugin-warrior
./build.sh server-java
./build.sh mobile-java
./build.sh lamp
./build.sh php
./build.sh python
./build.sh ruby-rails
./build.sh cplusplus
