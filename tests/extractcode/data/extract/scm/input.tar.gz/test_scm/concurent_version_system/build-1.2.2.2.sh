#  Copyright (c) 2003-2008 by nexB, Inc. http://www.nexb.com/ - All rights reserved.
#  This software is licensed under the terms of the Open Software License version 2.1.
#  A copy of the license is available at http://opensource.org/licenses/osl-2.1.php

# Only the 1.2.2.2 release:

# build and uploaded
# php
# server-java

# to upload
# mobile-java
# python
# eclipse-tools
./anteclipse clean

./build.sh lamp
./anteclipse clean
./build.sh ruby-rails
./build.sh rubyeclipse
./build.sh radrails