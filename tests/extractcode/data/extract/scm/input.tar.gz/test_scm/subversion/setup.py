#
# Copyright (c) 2008-2009 by nexB, Inc. http://www.nexb.com/ - All rights reserved.
# This software is NOT RELEASED YET and NOT LICENSED unless agreed with nexB.
#

import dejacode
dejacode._WITH_SNIPPET = True # Run the snippet tests as part of the automated tests, but nowhere else for now
from dejacode.tests.setup import setup_test

setup_test("dejacode.tests.suite.setuptools_suite")
