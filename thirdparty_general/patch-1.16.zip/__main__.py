import sys

import patch
sys.exit(patch.main())
