.. toctree::
    :maxdepth: 2

.. include:: ../README.rst



API Reference
=============

.. automodule:: ahocorasick
    :members:
    :undoc-members:
    :special-members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

