typecode
========
typecode provides file type detection functionality to ScanCode toolkit.
