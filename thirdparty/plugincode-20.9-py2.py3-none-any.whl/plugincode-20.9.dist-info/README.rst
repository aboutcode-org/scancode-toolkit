plugincode
==========
plugincode is a library that provides plugin functionality for ScanCode toolkit.
