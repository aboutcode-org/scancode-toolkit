Release notes
-------------

### Version 0.9.3

*2020-04-20* -- Add support for CodeArchive and minor refactorings.


### Version 0.9.2

*2020-04-17* -- Initial release.


