=====
Usage
=====

To use Dependency Parser in a project::

    import dparse
