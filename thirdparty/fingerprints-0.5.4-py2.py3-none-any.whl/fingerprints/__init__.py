from fingerprints.generate import generate

__all__ = [generate]
