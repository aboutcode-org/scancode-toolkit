:orphan:

================
Internal Details
================

This content is now covered in the :doc:`Architecture section <development/architecture/index>`.
