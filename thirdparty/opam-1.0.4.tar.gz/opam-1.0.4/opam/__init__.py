from opam import opam
load=opam.load
getversion=opam.getversion
getmaintainer=opam.getmaintainer
getsynopsis=opam.getsynopsis