Authors
-------

IntbitSet was originally developed for use in `Invenio <http://inveniosoftware.org>`_ 
digital library software and is now used by several other projects as a library
that need a fast integer set.

Contact the current maintainer at `Philippe Ombredanne <pombredanne@gmail.com>`_
Contact Invenio at `info@inveniosoftware.org <mailto:info@inveniosoftware.org>`_

Contributors
^^^^^^^^^^^^
* Alessio Deiana <alessio.deiana@cern.ch>
* Jiri Kuncar <jiri.kuncar@cern.ch>
* Lars Holm Nielsen <lars.holm.nielsen@cern.ch>
* Marco Neumann <marco@crepererum.net>
* Nikola Yolov <nikola.yolov@cern.ch>
* Philippe Ombredanne <pombredanne@gmail.com>
* Samuele Kaplun <samuele.kaplun@cern.ch>
* Tibor Simko <tibor.simko@cern.ch>
