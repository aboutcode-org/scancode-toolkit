# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

# Used in the tests for run_python_module
import sys
print("runmod3: passed %s" % sys.argv[1])
