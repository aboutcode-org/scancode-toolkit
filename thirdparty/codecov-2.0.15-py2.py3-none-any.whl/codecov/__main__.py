import codecov


if __name__ == '__main__':
    codecov.main()
