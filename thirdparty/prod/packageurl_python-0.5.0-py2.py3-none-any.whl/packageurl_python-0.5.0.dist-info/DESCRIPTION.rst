Python library to parse and build "purl" aka. package URLs. This is a microlibrary implementing the purl spec at https://github.com/package-url


