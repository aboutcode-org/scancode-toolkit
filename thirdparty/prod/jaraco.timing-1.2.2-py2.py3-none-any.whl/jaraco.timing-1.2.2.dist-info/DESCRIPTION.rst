jaraco.timing
=============

``jaraco.timing`` provides some Python functions that are useful for timing how
much real world time a piece of code takes to execute and limiting the
frequency at which a function is called.


