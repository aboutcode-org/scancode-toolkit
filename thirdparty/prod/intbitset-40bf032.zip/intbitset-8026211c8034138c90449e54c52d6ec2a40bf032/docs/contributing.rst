Contributing
============

See <http://invenio-software.org/wiki/Development/Contributing> for now.
