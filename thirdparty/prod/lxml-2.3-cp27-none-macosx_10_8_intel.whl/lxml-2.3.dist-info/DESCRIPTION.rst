lxml is a Pythonic, mature binding for the libxml2 and libxslt libraries.  It
provides safe and convenient access to these libraries using the ElementTree
API.

It extends the ElementTree API significantly to offer support for XPath,
RelaxNG, XML Schema, XSLT, C14N and much more.

To contact the project, go to the `project home page
<http://codespeak.net/lxml/>`_ or see our bug tracker at
https://launchpad.net/lxml

In case you want to use the current in-development version of lxml,
you can get it from the subversion repository at
http://codespeak.net/svn/lxml/trunk .  Note that this requires Cython
to build the sources, see the build instructions on the project home
page.  To the same end, running Running ``easy_install lxml==dev``
will install lxml from
http://codespeak.net/svn/lxml/trunk#egg=lxml-dev


After an official release of a new stable series, bug fixes may become
available at
http://codespeak.net/svn/lxml/branch/lxml-2.3 .
Running ``easy_install lxml==2.3bugfix`` will install
the unreleased branch state from
http://codespeak.net/svn/lxml/branch/lxml-2.3#egg=lxml-2.3bugfix
as soon as a maintenance branch has been established.
2.3 (2011-02-06)
================

Features added
--------------

* When looking for children, ``lxml.objectify`` takes '{}tag' as
  meaning an empty namespace, as opposed to the parent namespace.

Bugs fixed
----------

* When finished reading from a file-like object, the parser
  immediately calls its ``.close()`` method.

* When finished parsing, ``iterparse()`` immediately closes the input
  file.

* Work-around for libxml2 bug that can leave the HTML parser in a
  non-functional state after parsing a severly broken document (fixed
  in libxml2 2.7.8).

* ``marque`` tag in HTML cleanup code is correctly named ``marquee``.

Other changes
--------------

* Some public functions in the Cython-level C-API have more explicit
  return types.




