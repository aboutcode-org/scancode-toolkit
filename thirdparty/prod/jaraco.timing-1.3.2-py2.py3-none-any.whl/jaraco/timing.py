from __future__ import absolute_import

import warnings

from tempora.timing import *


warnings.warn(
	"Use the tempora.timing package instead",
	DeprecationWarning,
)
