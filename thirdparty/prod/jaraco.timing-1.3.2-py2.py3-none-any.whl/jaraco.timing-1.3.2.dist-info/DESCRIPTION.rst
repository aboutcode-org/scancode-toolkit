jaraco.timing is deprecated. Use `tempora <https://pypi.org/project/tempora>`_
instead.


