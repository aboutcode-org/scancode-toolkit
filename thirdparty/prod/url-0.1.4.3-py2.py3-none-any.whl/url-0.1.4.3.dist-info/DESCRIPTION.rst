Some helper functions for parsing URLs, sanitizing them, normalizing them.

This includes support for escaping, unescaping, punycoding, unpunycoding,
cleaning parameter and query strings, and a little more sanitization.


