# -*- coding: utf-8 -*-

version_info = ('1', '1', '1')

__version__ = '{0}.{1}.{2}'.format(*version_info)
