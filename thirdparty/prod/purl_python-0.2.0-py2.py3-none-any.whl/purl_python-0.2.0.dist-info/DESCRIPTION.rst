Python library to parse and build "purl" aka. package URLs.


