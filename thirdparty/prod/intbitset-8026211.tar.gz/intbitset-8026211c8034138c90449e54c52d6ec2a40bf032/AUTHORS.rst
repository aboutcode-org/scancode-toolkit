Authors
-------

IntbitSet is developed for use in `Invenio <http://invenio-software.org>`_ digital library software.

Contact us at `info@invenio-software.org <mailto:info@invenio-software.org>`_

Contributors
^^^^^^^^^^^^
* Alessio Deiana <alessio.deiana@cern.ch>
* Jiri Kuncar <jiri.kuncar@cern.ch>
* Lars Holm Nielsen <lars.holm.nielsen@cern.ch>
* Marco Neumann <marco@crepererum.net>
* Nikola Yolov <nikola.yolov@cern.ch>
* Samuele Kaplun <samuele.kaplun@cern.ch>
* Tibor Simko <tibor.simko@cern.ch>
