The ABOUT tool and ABOUT files provide a simple way
to document the provenance (origin and license) and other important or
interesting information about third-party software components that you use
in your project.

