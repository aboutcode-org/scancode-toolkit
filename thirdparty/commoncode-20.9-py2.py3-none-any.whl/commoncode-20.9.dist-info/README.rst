commoncode
==========
A set of common functions and utilities for handling various things like paths, dates,
files and hashes
