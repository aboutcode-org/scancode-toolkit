

# https://en.wikipedia.org/wiki/Cyrillic_script_in_Unicode
# Cyrillic: U+0400–U+04FF, 256 characters
# Cyrillic Supplement: U+0500–U+052F, 48 characters
# Cyrillic Extended-A: U+2DE0–U+2DFF, 32 characters
# Cyrillic Extended-B: U+A640–U+A69F, 96 characters
# Cyrillic Extended-C: U+1C80–U+1C8F, 9 characters
# Phonetic Extensions: U+1D2B, U+1D78, 2 Cyrillic characters
# Combining Half Marks: U+FE2E–U+FE2F, 2 Cyrillic characters
