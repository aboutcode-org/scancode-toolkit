.. currentmodule:: javaproperties

``Properties`` Class
====================
.. autoclass:: Properties
