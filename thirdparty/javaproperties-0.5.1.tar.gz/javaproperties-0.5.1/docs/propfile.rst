.. currentmodule:: javaproperties

``PropertiesFile`` Class
========================
.. autoclass:: PropertiesFile
