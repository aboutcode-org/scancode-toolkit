.. currentmodule:: javaproperties

Low-Level Utilities
===================
.. autofunction:: escape
.. autofunction:: java_timestamp
.. autofunction:: join_key_value
.. autofunction:: parse
.. autofunction:: to_comment
.. autofunction:: unescape
.. autoexception:: InvalidUEscapeError
    :show-inheritance:
